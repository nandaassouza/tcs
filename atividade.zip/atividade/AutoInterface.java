
package atividade;

public interface AutoInterface {
    void ligar();
    void desligar();
    void abastecer();
    void acelerar();
    void status();
}
